from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    if request.method == 'POST':
        a = float(request.form.get("a", 0))
        b = float(request.form.get("b", 0))
        op = request.form.get("operation")
        if op == 'add':
            result = a + b
        elif op == 'subtract':
            result = a - b
        elif op == 'multiply':
            result = a * b
        elif op == 'divide':
            result = a / b if b != 0 else 'Error'
    return render_template('index.html', result=result)
