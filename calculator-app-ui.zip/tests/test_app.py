import app

def test_add_route():
    with app.app.test_client() as client:
        response = client.post('/', data=dict(a=2, b=3, operation='add'))
        assert b'5.0' in response.data
